/**
 * @author sliva 
 */
package compiler.phases.seman;

import compiler.common.report.*;
import compiler.data.abstree.*;
import compiler.data.abstree.attribute.AbsAttribute;
import compiler.data.abstree.visitor.*;
import compiler.data.type.*;
import compiler.data.type.property.*;

/**
 * Type resolving: the result is stored in {@link SemAn#declaresType},
 * {@link SemAn#isType}, and {@link SemAn#isOfType}.
 * 
 * @author sliva
 */
public class TypeResolver extends AbsFullVisitor<SemType, TypeResolver.Phase> {

	/**
	 * Different phases of type resolving.
	 * 
	 * @author sliva
	 */
	protected static enum Phase {

		/** Type checking of expressions. */
		CHECK,

		/**
		 * The phase for declaring type names. Every type declaration in the current
		 * declaration group is associated with its own empty {@link SemNamedType}.
		 */
		TYP_DECLARE,

		/**
		 * The phase for defining types (after {@link TYP_DECLARE}). Every
		 * {@link SemNamedType} of a type declaration in the current declaration group
		 * is assigned its type.
		 */
		TYP_DEFINE,

		/**
		 * The phase for type checking of types (after {@link TYP_DEFINE}). Every type
		 * represented by {@link SemNamedType} of a type declaration in the current
		 * declaration group is checked.
		 */
		TYP_CHECK,

		/**
		 * The phase for typing and type checking (after {@link TYP_CHECK}). A type of
		 * every variable in the current declaration group is defined and checked.
		 */
		VAR,

		/**
		 * The phase for typing functions (after {@link VAR}. Types of parameters and
		 * the type of function result of every function in the current declaration
		 * group are defined.
		 */
		FUN_DEFINE,

		/**
		 * The phase for type checking functions (after {@link FUN_DEFINE}). Types of
		 * parameters and the type of function result of every function in the current
		 * declaration group are checked. Furthermore, the return value of a function is
		 * typed and type checked.
		 */
		FUN_CHECK,
	};

	@Override
	public SemType visit(AbsSource source, Phase visArg) {
		super.visit(source, Phase.TYP_DECLARE);
		super.visit(source, Phase.TYP_DEFINE);
		super.visit(source, Phase.TYP_CHECK);
		super.visit(source, Phase.VAR);
		super.visit(source, Phase.FUN_DEFINE);
		super.visit(source, Phase.FUN_CHECK);
		return null;
	}

	@Override
	public SemType visit(AbsTypDecl typDecl, Phase visArg) {
		if(visArg == Phase.TYP_DECLARE) {
			// un typDecl.name je narobe
			SemAn.declaresType.put(typDecl, new SemNamedType(typDecl.name));
		}
		else if(visArg == Phase.TYP_DEFINE){
			System.out.println("Type define");
			SemType type = typDecl.type.accept(this, visArg);
			System.out.println(type);

		}
		return null;
	}

	@Override
	public SemType visit(AbsTypName typName, Phase visArg) {
		//System.out.println(typName.name);
		//SemAn.declaresType.get(typName.name);
		//SemType type = typName.accept(this, visArg);
		return null;
	}

	@Override
	public SemType visit(AbsAtomType atomType, Phase visArg) {
		//System.out.println(atomType.type);
		if(atomType.type == AbsAtomType.Type.VOID){
			SemAn.isType.put(atomType, new SemVoidType());
			return new SemVoidType();
		}
		else if(atomType.type == AbsAtomType.Type.BOOL){
			SemAn.isType.put(atomType, new SemBoolType());
			return new SemBoolType();
		}
		else if(atomType.type == AbsAtomType.Type.CHAR){
			SemAn.isType.put(atomType, new SemCharType());
			return new SemCharType();
		}
		else if(atomType.type == AbsAtomType.Type.INT){
			SemAn.isType.put(atomType, new SemIntType());
			return new SemIntType();
		}
		return super.visit(atomType, visArg);
	}
}
