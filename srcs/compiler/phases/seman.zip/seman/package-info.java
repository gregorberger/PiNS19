/**
 * Semantic analysis.
 * 
 * @author sliva
 */
package compiler.phases.seman;
